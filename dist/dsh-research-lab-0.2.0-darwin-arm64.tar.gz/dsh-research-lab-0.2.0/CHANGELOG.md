# Changelog

## v0.2.0 — 2026-10-23

双领域 + 数据复现版本。

- 新增 HealthResearch 领域模板与 heart-disease 数据包（H1–H5 完整管线）：
  审计（缺失 ca=4/thal=2，完整案例 297）→ Logistic 基线 → 防泄漏划分与 5 折 CV
  （AUC 0.869±0.069）→ 留出集评价（AUC 0.950、Youden 阈值、Brier 0.094、校准曲线）
- 独立参考实现双路互证：教育侧 numpy-OLS vs statsmodels 逐位一致（|Δcoef|=0）；
  健康侧 GLM/IRLS + 秩和 AUC vs sklearn（跨求解器容差 0.005，同概率秩和差 0.0）
- `scripts/verify.py` 总验收 31 项全绿（SHA256 完整性 / 确定性复跑 / 交叉验证 / 协议断言）
- Presets：research-lab / edu-research / health-research（DSH 0.2.1-rc.2 基线）

## v0.1.0 — 2026-10-23

可运行单领域版本。

- EduResearch 教学管线 T1–T5 端到端（真实数据 649×33）：
  审计（649 行 0 缺失 0 重复；raw 字节级核查发现 G1/G2 引号数字——类型漂移教学点）
  → 单变量关联（studytime Spearman ρ=0.275）→ M1 多变量回归（调整 R²=0.263，
  studytime +0.51 / failures −1.67，异方差与残差非正态诊断在案）
  → M2 泄漏对照（含 G1/G2 后调整 R²=0.850，任务定义变化讲解）
  → 报告/图表/日志交付
- 通用 Skills 八件 + 教育领域 Skills；templates/new-domain 定制模板
