"""run_t1_t5.py — EduResearch 教学管线（协议 datasets/education-student-performance/protocol.md）

T1 审计 → T2 单变量关联 → T3 M1 回归（+HC3 敏感性）→ T4 M2 泄漏对照 → T5 复现交付。
确定性：全程无随机过程，可精确复现。产物写入 examples/education-demo/outputs/。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from tools.data_audit import audit_csv  # noqa: E402
from tools.regression import fit_ols, public_view, save_residual_figure  # noqa: E402

RAW = REPO / "datasets/education-student-performance/raw/student-por.csv"
OUT = REPO / "examples/education-demo/outputs"

M1_FORMULA = "G3 ~ C(school) + C(sex) + Medu + Fedu + studytime + failures + absences"
M2_FORMULA = M1_FORMULA + " + G1 + G2"


def t1_audit() -> dict:
    audit = audit_csv(RAW, sep=";")
    assert audit["ok"], audit
    assert audit["n_rows"] == 649 and audit["n_cols"] == 33, "样本规模与来源声明不符"

    # 原始字节检查：G1/G2 取值带引号（静默类型漂移的教学证据）
    header = RAW.read_text(encoding="utf-8-sig").splitlines()[0].split(";")
    g1_i, g2_i = header.index("G1"), header.index("G2")
    second = RAW.read_text(encoding="utf-8-sig").splitlines()[1].split(";")
    quoted_g1 = second[g1_i].strip().startswith('"')
    quoted_g2 = second[g2_i].strip().startswith('"')
    assert quoted_g1 and quoted_g2, "预期 raw 文件中 G1/G2 带引号（类型漂移教学点缺失）"

    df = pd.read_csv(RAW, sep=";", skipinitialspace=True)
    # 类型断言：解析层显式核查，不信任静默推断
    int_cols = ["age", "Medu", "Fedu", "traveltime", "studytime", "failures",
                "famrel", "freetime", "goout", "Dalc", "Walc", "health",
                "absences", "G1", "G2", "G3"]
    for col in int_cols:
        assert pd.api.types.is_integer_dtype(df[col]), f"{col} 应为整数型，实测 {df[col].dtype}"
    cat_cols = ["school", "sex", "address", "famsize", "Pstatus", "Mjob", "Fjob",
                "reason", "guardian", "schoolsup", "famsup", "paid", "activities",
                "nursery", "higher", "internet", "romantic"]
    for col in cat_cols:
        assert df[col].dtype == object, f"{col} 应为类别型"
    assert set(df["school"].unique()) <= {"GP", "MS"}
    assert df["G3"].between(0, 20).all()

    audit["raw_bytes_check"] = {
        "g1_quoted_in_raw": quoted_g1,
        "g2_quoted_in_raw": quoted_g2,
        "lesson": "引号数字被标准解析器静默吸收为整数——解析层必须显式断言目标类型",
    }
    audit["dtype_assertions_passed"] = True
    return audit


def t2_associations(df: pd.DataFrame) -> list[dict]:
    rows = []
    for var in ["studytime", "failures", "Medu", "Fedu"]:
        rho, p = stats.spearmanr(df[var], df["G3"])
        rows.append({"variable": var, "method": "spearman",
                     "statistic": round(float(rho), 6), "p_value": float(p)})
    r_p, p_p = stats.pearsonr(df["absences"], df["G3"])
    rho_a, p_a = stats.spearmanr(df["absences"], df["G3"])
    rows.append({"variable": "absences", "method": "pearson",
                 "statistic": round(float(r_p), 6), "p_value": float(p_p)})
    rows.append({"variable": "absences", "method": "spearman",
                 "statistic": round(float(rho_a), 6), "p_value": float(p_a)})
    groups = [g["G3"].values for _, g in df.groupby("studytime")]
    h, p_kw = stats.kruskal(*groups)
    rows.append({"variable": "studytime(x4 groups)", "method": "kruskal_wallis",
                 "statistic": round(float(h), 6), "p_value": float(p_kw),
                 "group_means": [round(float(g.mean()), 4) for g in groups],
                 "group_ns": [int(len(g)) for g in groups]})
    return rows


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "tables").mkdir(exist_ok=True)
    (OUT / "figures").mkdir(exist_ok=True)

    t1 = t1_audit()
    df = pd.read_csv(RAW, sep=";", skipinitialspace=True)
    t2 = t2_associations(df)

    m1 = fit_ols(df, M1_FORMULA, label="M1_without_prior_grades")
    m1_hc3 = fit_ols(df, M1_FORMULA, label="M1_HC3_robust")
    # HC3 稳健标准误（异方差的敏感性检查，系数不变、SE 变）
    import statsmodels.formula.api as smf
    m1_hc3_fit = smf.ols(M1_FORMULA, data=df).fit(cov_type="HC3")
    m1["hc3_se"] = {t: round(float(m1_hc3_fit.bse[t]), 6) for t in m1_hc3_fit.params.index}
    m2 = fit_ols(df, M2_FORMULA, label="M2_with_prior_grades_leakage_audit")

    results = {
        "suite": "education-student-performance",
        "protocol_version": "V1.0",
        "data_file": "raw/student-por.csv",
        "t1_audit": t1,
        "t2_associations": t2,
        "t3_model_m1": public_view(m1),
        "t4_model_m2": public_view(m2),
        "t4_adj_r2_delta": round(m2["adj_r_squared"] - m1["adj_r_squared"], 6),
        "reading_note": (
            "M2 含 G1/G2：调整 R² 大幅上升但任务定义改变为期末解释/含泄漏预测；"
            "回答研究问题 RQ1 的只有 M1。所有结论为关联，不构成因果。"
        ),
    }

    fig_m1 = save_residual_figure(m1, OUT / "figures/m1_residuals.png",
                                  "M1 residuals vs fitted (G3 model)")
    fig_m2 = save_residual_figure(m2, OUT / "figures/m2_residuals.png",
                                  "M2 residuals vs fitted (with G1/G2)")
    results["figures"] = {"m1_residuals": fig_m1, "m2_residuals": fig_m2}

    pd.DataFrame(t2).to_csv(OUT / "tables/t2_associations.csv", index=False)
    pd.DataFrame(m1["coefficients"]).to_csv(OUT / "tables/m1_coefficients.csv", index=False)
    pd.DataFrame(m2["coefficients"]).to_csv(OUT / "tables/m2_coefficients.csv", index=False)

    (OUT / "results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")

    from tools.report_builder import build_education_report
    (OUT / "report.md").write_text(build_education_report(results), encoding="utf-8")

    # 控制台摘要（供课堂投屏核对）
    print(json.dumps({
        "ok": True,
        "t1": {"n": t1["n_rows"], "dups": t1["exact_duplicate_rows"],
               "missing": t1["total_missing_cells"]},
        "t2_studytime_rho": t2[0]["statistic"],
        "t3_m1_adj_r2": m1["adj_r_squared"],
        "t4_m2_adj_r2": m2["adj_r_squared"],
        "delta": results["t4_adj_r2_delta"],
        "outputs": str(OUT),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
