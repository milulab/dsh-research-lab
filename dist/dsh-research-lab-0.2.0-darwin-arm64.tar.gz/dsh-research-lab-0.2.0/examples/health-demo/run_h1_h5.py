"""run_h1_h5.py — HealthResearch 教学管线（协议 datasets/health-heart-disease/protocol.md）

H1 审计 → H2 基线 → H3 划分/CV（防泄漏）→ H4 评价（ROC/阈值/校准）→ H5 复现交付。
随机性已锁定 seed=42，结果可精确复现；另附独立口径 ROC-AUC 交叉核验（秩/游程法）。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from tools.classification import load_heart_csv, run_pipeline, save_figures  # noqa: E402
from tools.report_builder import build_health_report  # noqa: E402

RAW = REPO / "datasets/health-heart-disease/raw/processed.cleveland.data"
OUT = REPO / "examples/health-demo/outputs"


def independent_auc(y_true: np.ndarray, scores: np.ndarray) -> float:
    """与 sklearn 无关的 ROC-AUC 口径：Mann-Whitney U / 秩和法（含并列平均秩）。"""
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty(len(scores), dtype=float)
    sorted_scores = scores[order]
    i = 0
    while i < len(scores):
        j = i
        while j + 1 < len(scores) and sorted_scores[j + 1] == sorted_scores[i]:
            j += 1
        ranks[order[i : j + 1]] = (i + j + 2) / 2.0
        i = j + 1
    n_pos = int((y_true == 1).sum())
    n_neg = int((y_true == 0).sum())
    u = ranks[y_true == 1].sum() - n_pos * (n_pos + 1) / 2.0
    return float(u / (n_pos * n_neg))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "tables").mkdir(exist_ok=True)
    (OUT / "figures").mkdir(exist_ok=True)

    loaded = load_heart_csv(RAW)
    assert loaded["ok"], loaded
    clean = loaded["data"]
    result = run_pipeline(clean, seed=42, cv_folds=5)
    result["h1_audit"] = loaded["audit"]

    # H4 增补：独立口径 AUC 交叉核验（sklearn vs 秩和法，应一致到浮点容差）
    import pandas as pd
    from sklearn.metrics import roc_auc_score
    from sklearn.model_selection import train_test_split
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression

    features = result["features"]
    X = clean[features]
    y = clean["target"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2,
                                              random_state=42, stratify=y)
    pipe = Pipeline([("scaler", StandardScaler()),
                     ("clf", LogisticRegression(max_iter=1000))]).fit(X_tr, y_tr)
    proba_te = pipe.predict_proba(X_te)[:, 1]
    auc_sklearn = float(roc_auc_score(y_te, proba_te))
    auc_rank = independent_auc(np.asarray(y_te), np.asarray(proba_te))
    result["test"]["auc_crosscheck"] = {
        "sklearn": round(auc_sklearn, 6),
        "rank_method": round(auc_rank, 6),
        "abs_diff": round(abs(auc_sklearn - auc_rank), 9),
    }
    assert abs(auc_sklearn - auc_rank) < 1e-9, "两套 AUC 口径不一致，禁止发布结果"

    # 系数方向表（标准化空间 → 解读顺序参考，不输出为临床效应量）
    coef_rows = [
        {"feature": f, "coef_scaled": c}
        for f, c in sorted(result["model"]["coefficients_scaled_space"].items(),
                           key=lambda kv: -abs(kv[1]))
    ]
    pd.DataFrame(coef_rows).to_csv(OUT / "tables/coefficients_scaled.csv", index=False)
    pd.DataFrame(result["test"]["threshold_sweep"]).to_csv(
        OUT / "tables/threshold_sweep.csv", index=False)

    figs = save_figures(result, OUT / "figures")
    result["figures"] = figs

    (OUT / "results.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    (OUT / "report.md").write_text(build_health_report(result), encoding="utf-8")

    print(json.dumps({
        "ok": True,
        "h1": {"n_raw": loaded["audit"]["n_rows"],
               "missing": loaded["audit"]["missing_by_column"],
               "n_complete": loaded["audit"]["n_after_complete_case"],
               "target": loaded["audit"]["target_counts"]},
        "cv_auc": result["cv"]["mean_auc"],
        "test_auc": result["test"]["roc_auc"],
        "auc_crosscheck_diff": result["test"]["auc_crosscheck"]["abs_diff"],
        "youden": result["test"]["youden"],
        "brier": result["test"]["brier"],
        "outputs": str(OUT),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
