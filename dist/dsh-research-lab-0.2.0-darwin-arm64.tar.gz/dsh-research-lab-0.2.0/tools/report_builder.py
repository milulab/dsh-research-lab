"""report_builder.py — 由结构化统计结果组装研究报告（T5/H5）

输入 examples 管线产出的 results JSON（t1_audit/t2_t4/h1_h4 段），输出
Markdown 报告。规则：所有数字只从传入 JSON 引用，本模块不产生任何统计值；
局限声明为必填段，来源与映射规则自动附在文末。

用法：
  python tools/report_builder.py --education results.json --out report.md
  python tools/report_builder.py --health results.json --out report.md
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

EDUCATION_FOOTER = """## 数据与复现

- 数据：UCI Student Performance（Cortez & Silva 2008，CC BY 4.0），葡萄牙语课程
  649 名中学学生；原始文件 SHA256 见 metadata/source.yml。
- 复现：`python examples/education-demo/run_t1_t5.py`；校验：
  `python scripts/verify.py --suite education`。
- 本报告为教学演示产物，不代表任何真实培训效果。"""

HEALTH_FOOTER = """## 数据与复现

- 数据：UCI Heart Disease processed Cleveland 子集（Detrano et al. 1989，CC BY 4.0），
  303 例历史研究数据；原始文件 SHA256 见 metadata/source.yml。
- 复现：`python examples/health-demo/run_h1_h5.py`；校验：
  `python scripts/verify.py --suite health`。
- **不得用于真实临床诊断**；本报告为教学演示产物。"""


def _fmt(x, nd=4):
    if x is None:
        return "—"
    if isinstance(x, float):
        return f"{x:.{nd}f}"
    return str(x)


def build_education_report(r: dict) -> str:
    t1 = r["t1_audit"]
    t2 = r["t2_associations"]
    m1 = r["t3_model_m1"]
    m2 = r["t4_model_m2"]
    lines = [
        "# 学习行为与学业成绩的关联分析（EduResearch 教学报告）",
        "",
        f"样本：葡萄牙语课程 {t1['n_rows']} 名学生 × {t1['n_cols']} 字段；"
        f"完全重复行 {t1['exact_duplicate_rows']}；缺失单元格 {t1['total_missing_cells']}。",
        "",
        "## T2 单变量关联（仅表述关联，不作因果解释）",
        "",
        "| 变量 | 方法 | 统计量 | p 值 |",
        "|---|---|---|---|",
    ]
    for row in t2:
        lines.append(
            f"| {row['variable']} | {row['method']} | {row['statistic']} | {_fmt(row['p_value'])} |"
        )
    lines += [
        "",
        f"## T3 多变量回归 M1（不含 G1/G2）：n={m1['n_obs']}，"
        f"R²={_fmt(m1['r_squared'])}，调整 R²={_fmt(m1['adj_r_squared'])}",
        "",
        "| 项 | 系数 | 95% CI | p 值 |",
        "|---|---|---|---|",
    ]
    for c in m1["coefficients"]:
        lines.append(
            f"| {c['term']} | {_fmt(c['coef'])} | [{_fmt(c['ci_low'])}, {_fmt(c['ci_high'])}] "
            f"| {_fmt(c['p_value'])} |"
        )
    lines += [
        "",
        f"诊断：Breusch-Pagan LM p={_fmt(m1['breusch_pagan']['lm_pvalue'])}（异方差提示）；"
        f"Jarque-Bera p={_fmt(m1['jarque_bera']['pvalue'])}（残差非正态提示）；"
        f"最大解释变量 VIF={_fmt(m1.get('vif_max'))}（共线性）。",
        "",
        f"## T4 目标信息时点对照：M2（含 G1/G2）调整 R²={_fmt(m2['adj_r_squared'])}，"
        f"较 M1 提升 {_fmt(m2['adj_r_squared'] - m1['adj_r_squared'])}",
        "",
        "解读：G1/G2 纳入后解释力大幅上升，但任务定义随之改变——M2 回答的是"
        "“期末解释/含泄漏预测”，不能用于解释学习行为的独立作用；回答 RQ1 的只有 M1。",
        "",
        "## 局限",
        "",
        "观察性数据，全部结论为关联而非因果；样本限于 2008 年葡萄牙两所中学的葡语课程；"
        "异方差与残差非正态提示应同时报告稳健标准误作为敏感性检查（见 run_t1_t5 输出）。",
        "",
        EDUCATION_FOOTER,
    ]
    return "\n".join(lines) + "\n"


def build_health_report(r: dict) -> str:
    a = r["h1_audit"]
    cv = r["cv"]
    t = r["test"]
    t05 = t["threshold_05"]
    yd = t["youden"]
    lines = [
        "# 心脏病风险分类模型验证（HealthResearch 教学报告）",
        "",
        f"H1 审计：原始 {a['n_rows']} 例；缺失 ca={a['missing_by_column'].get('ca', 0)}、"
        f"thal={a['missing_by_column'].get('thal', 0)}；完整案例 {a['n_after_complete_case']} 例；"
        f"标签映射规则：{a['label_mapping']}。",
        f"标签分布：阴性 {a['target_counts']['0']} / 阳性 {a['target_counts']['1']}。",
        "",
        f"H3 划分与 CV：训练 {r['n_train']} / 测试 {r['n_test']}（分层 80/20，seed={r['seed']}）；"
        f"{cv['folds']} 折分层 CV AUC = {_fmt(cv['mean_auc'])} ± {_fmt(cv['std_auc'])}。",
        "",
        f"H4 测试集 ROC-AUC = {_fmt(t['roc_auc'])}",
        "",
        "| 阈值 | TP | FP | FN | TN | 敏感度 | 特异度 | 准确率 |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for name, blk in [("0.5", t05), (f"Youden {_fmt(yd['threshold'], 3)}", yd)]:
        cm = blk["confusion_matrix"]
        lines.append(
            f"| {name} | {cm['tp']} | {cm['fp']} | {cm['fn']} | {cm['tn']} "
            f"| {_fmt(blk['sensitivity'])} | {_fmt(blk['specificity'])} | {_fmt(blk['accuracy'])} |"
        )
    lines += [
        "",
        f"Brier 分数 = {_fmt(t['brier'])}（校准曲线见 outputs/figures/calibration.png）；"
        f"阈值扫描表（19 档）见 outputs/tables/threshold_sweep.csv。",
        "",
        "## 局限",
        "",
        f"测试集仅 {r['n_test']} 例，指标存在明显抽样波动（CV 标准差 ±{_fmt(cv['std_auc'], 3)}）；"
        "历史研究数据与现代临床环境不可比；预测因子关联不构成因果；**不得用于真实临床诊断**；"
        "类别特征沿用上游整数编码的简化需在正式研究中重新审视。",
        "",
        HEALTH_FOOTER,
    ]
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Assemble teaching report from results JSON")
    parser.add_argument("--education", default="", help="education results.json")
    parser.add_argument("--health", default="", help="health results.json")
    parser.add_argument("--out", required=True, help="输出 Markdown 路径")
    args = parser.parse_args(argv)

    if bool(args.education) == bool(args.health):
        sys.stdout.write(
            json.dumps({"ok": False, "error": "exactly one of --education/--health required"}) + "\n"
        )
        return
    src = Path(args.education or args.health)
    r = json.loads(src.read_text(encoding="utf-8"))
    report = build_education_report(r) if args.education else build_health_report(r)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report, encoding="utf-8")
    sys.stdout.write(json.dumps({"ok": True, "report": str(out), "chars": len(report)}) + "\n")


if __name__ == "__main__":
    main()
